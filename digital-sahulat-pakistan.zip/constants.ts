
import { Service, Application, ApplicationStatus, User } from './types';
import { 
    NewRegistrationIcon, BFormIcon, CorrectionIcon, 
    LateRegIcon, FrcIcon, DeathCertificateIcon, PensionIcon, GratuityIcon, VerificationIcon
} from './components/icons';

interface ServiceCategory {
    title: { en: string; ur: string };
    items: Service[];
}

export const SERVICE_CATEGORIES: ServiceCategory[] = [
    {
        title: { en: 'Civil Registration', ur: 'سول رجسٹریشن' },
        items: [
            {
                id: 'birth-cert',
                name: { en: 'Birth Certificate (UC)', ur: 'پیدائش کا سرٹیفکیٹ' },
                description: { en: 'Facilitation for obtaining a new birth certificate from the Union Council.', ur: 'یونین کونسل سے نیا برتھ سرٹیفکیٹ حاصل کرنے کی سہولت۔' },
                fee: 800,
                icon: NewRegistrationIcon,
                requiredDocs: { 
                    en: ['Hospital Discharge Papers', 'Parents\' CNIC Copies', 'Filled Application Form'],
                    ur: ['ہسپتال سے ڈسچارج کے کاغذات', 'والدین کے شناختی کارڈ کی کاپیاں', 'پر شدہ درخواست فارم']
                },
            },
            {
                id: 'death-cert',
                name: { en: 'Death Certificate (UC)', ur: 'وفات کا سرٹیفکیٹ' },
                description: { en: 'Facilitation for obtaining a death certificate from the Union Council.', ur: 'یونین کونسل سے ڈیتھ سرٹیفکیٹ حاصل کرنے کی سہولت۔' },
                fee: 800,
                icon: DeathCertificateIcon,
                requiredDocs: { 
                    en: ['Deceased\'s CNIC Copy', 'Hospital/Cemetery Slip', 'Applicant\'s CNIC Copy'],
                    ur: ['متوفی کے شناختی کارڈ کی کاپی', 'ہسپتال/قبرستان کی پرچی', 'درخواست دہندہ کے شناختی کارڈ کی کاپی']
                },
            },
            {
                id: 'late-birth-reg',
                name: { en: 'Late Birth Registration', ur: 'تاخیری پیدائش کی رجسٹریشن' },
                description: { en: 'Registration of birth after the stipulated time period, requiring an affidavit.', ur: 'مقررہ مدت کے بعد پیدائش کی رجسٹریشن، حلف نامہ درکار ہے۔' },
                fee: 2000,
                icon: LateRegIcon,
                requiredDocs: { 
                    en: ['Affidavit for late registration', 'School records (if any)', 'Parents\' CNIC Copies'],
                    ur: ['تاخیر سے رجسٹریشن کے لیے حلف نامہ', 'اسکول کے ریکارڈ (اگر کوئی ہیں)', 'والدین کے شناختی کارڈ کی کاپیاں']
                },
            },
            {
                id: 'data-correction',
                name: { en: 'Data Correction', ur: 'کوائف میں درستگی' },
                description: { en: 'Correction of spelling, date of birth, or other details in birth/death certificates.', ur: 'پیدائش/وفات کے سرٹیفکیٹ میں ہجے، تاریخ پیدائش، یا دیگر تفصیلات کی درستگی۔' },
                fee: 1500,
                icon: CorrectionIcon,
                requiredDocs: { 
                    en: ['Original Certificate', 'Proof of correct information', 'Applicant\'s CNIC Copy'],
                    ur: ['اصل سرٹیفکیٹ', 'درست معلومات کا ثبوت', 'درخواست دہندہ کے شناختی کارڈ کی کاپی']
                },
            },
        ]
    },
    {
        title: { en: 'NADRA (non-CNIC)', ur: 'نادرا (غیر شناختی کارڈ)' },
        items: [
            {
                id: 'b-form',
                name: { en: 'B-Form / CRC', ur: 'ب فارم / سی آر سی' },
                description: { en: 'Child Registration Certificate for individuals under 18.', ur: '18 سال سے کم عمر افراد کے لیے چائلڈ رجسٹریشن سرٹیفکیٹ۔' },
                fee: 1000,
                icon: BFormIcon,
                 requiredDocs: { 
                    en: ['Birth Certificate', 'Parents\' CNIC Copies', 'Parents\' Marriage Certificate'],
                    ur: ['پیدائشی سرٹیفکیٹ', 'والدین کے شناختی کارڈ کی کاپیاں', 'والدین کا نکاح نامہ']
                },
            },
            {
                id: 'frc',
                name: { en: 'Family Registration Certificate', ur: 'فیملی رجسٹریشن سرٹیفکیٹ' },
                description: { en: 'Get a certificate showing your family composition as per NADRA records.', ur: 'نادرا ریکارڈ کے مطابق اپنے خاندان کی تشکیل کو ظاہر کرنے والا سرٹیفکیٹ حاصل کریں۔' },
                fee: 1200,
                icon: FrcIcon,
                 requiredDocs: { 
                    en: ['CNICs of all family members', 'Applicant\'s CNIC', 'Digital Photographs'],
                    ur: ['خاندان کے تمام افراد کے شناختی کارڈ', 'درخواست دہندہ کا شناختی کارڈ', 'ڈیجیٹل تصاویر']
                },
            },
        ]
    },
    {
        title: { en: 'Govt Employees (Post-Service)', ur: 'سرکاری ملازمین (بعد از ملازمت)' },
        items: [
             {
                id: 'pension-transfer',
                name: { en: 'Pension Transfer to Wife', ur: 'بیوی کو پنشن کی منتقلی' },
                description: { en: 'Process the transfer of a deceased government employee\'s pension to their wife.', ur: 'متوفی سرکاری ملازم کی پنشن ان کی اہلیہ کو منتقل کرنے کا عمل۔' },
                fee: 4000,
                icon: PensionIcon,
                requiredDocs: { 
                    en: ['Employee\'s Death Certificate', 'Wife\'s CNIC', 'Service Book', 'Nikahnama'],
                    ur: ['ملازم کا ڈیتھ سرٹیفکیٹ', 'بیوی کا شناختی کارڈ', 'سروس بک', 'نکاح نامہ']
                },
            },
            {
                id: 'gratuity-claim',
                name: { en: 'Gratuity / Benevolent Fund Claim', ur: 'گریجویٹی / بینوولنٹ فنڈ کلیم' },
                description: { en: 'File a claim for gratuity or benevolent funds after employee retirement or death.', ur: 'ملازم کی ریٹائرمنٹ یا وفات کے بعد گریجویٹی یا بینوولنٹ فنڈز کے لیے دعوی دائر کریں۔' },
                fee: 6000,
                icon: GratuityIcon,
                requiredDocs: { 
                    en: ['Retirement/Death notification', 'Applicant\'s CNIC', 'Succession Certificate (if applicable)'],
                    ur: ['ریٹائرمنٹ/وفات کا نوٹیفکیشن', 'درخواست دہندہ کا شناختی کارڈ', 'جانشینی سرٹیفکیٹ (اگر قابل اطلاق ہو)']
                },
            },
            {
                id: 'service-record-verification',
                name: { en: 'Service Record Verification', ur: 'سروس ریکارڈ کی تصدیق' },
                description: { en: 'Official verification of a government employee\'s service history and records.', ur: 'سرکاری ملازم کی سروس ہسٹری اور ریکارڈ کی سرکاری تصدیق۔' },
                fee: 2500,
                icon: VerificationIcon,
                requiredDocs: { 
                    en: ['Employee\'s CNIC', 'Letter from requiring department', 'Service details'],
                    ur: ['ملازم کا شناختی کارڈ', 'متعلقہ محکمہ کا خط', 'سروس کی تفصیلات']
                },
            },
        ]
    }
];

export const MOCK_USERS: User[] = [
    { id: 'user-123', name: 'Ahmed Khan', phone: '03001234567', password: 'password123', role: 'user'},
    { id: 'admin-456', name: 'Admin User', phone: '03329997862', password: 'admin786999M', role: 'admin'},
];


export const MOCK_APPLICATIONS: Application[] = [
    {
        id: 'app-001',
        userId: 'user-123',
        userName: 'Ahmed Khan',
        serviceId: 'b-form',
        serviceName: { en: 'B-Form / CRC', ur: 'ب فارم / سی آر سی' },
        status: ApplicationStatus.Completed,
        submittedAt: new Date('2023-10-15T10:00:00Z'),
        updatedAt: new Date('2023-10-20T14:30:00Z'),
    },
    {
        id: 'app-002',
        userId: 'user-123',
        userName: 'Ahmed Khan',
        serviceId: 'data-correction',
        serviceName: { en: 'Data Correction', ur: 'کوائف میں درستگی' },
        status: ApplicationStatus.InProgress,
        submittedAt: new Date('2024-01-20T09:00:00Z'),
        updatedAt: new Date('2024-01-22T11:00:00Z'),
    },
    {
        id: 'app-003',
        userId: 'user-123',
        userName: 'Ahmed Khan',
        serviceId: 'birth-cert',
        serviceName: { en: 'Birth Certificate (UC)', ur: 'پیدائش کا سرٹیفیکٹ' },
        status: ApplicationStatus.New,
        submittedAt: new Date(),
        updatedAt: new Date(),
    },
    {
        id: 'app-004',
        userId: 'user-123',
        userName: 'Ahmed Khan',
        serviceId: 'death-cert',
        serviceName: { en: 'Death Certificate (UC)', ur: 'وفات کا سرٹیفکیٹ' },
        status: ApplicationStatus.Rejected,
        submittedAt: new Date('2023-12-01T11:00:00Z'),
        updatedAt: new Date('2023-12-05T16:00:00Z'),
        rejectionReason: 'Invalid affidavit provided. Please resubmit with a notarized document.',
    },
];
