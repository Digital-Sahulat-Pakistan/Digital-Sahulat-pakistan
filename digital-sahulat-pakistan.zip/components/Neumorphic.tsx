
import React, { ReactNode } from 'react';

// Base styles for neumorphic elements
const neumorphicBase = 'bg-[#F0F2F5] rounded-xl transition-all duration-200';
const neumorphicShadow = 'shadow-[7px_7px_15px_#d1d9e6,-7px_-7px_15px_#ffffff]';
const neumorphicShadowHover = 'hover:shadow-[4px_4px_10px_#d1d9e6,-4px_-4px_10px_#ffffff]';
const neumorphicShadowActive = 'active:shadow-[inset_7px_7px_15px_#d1d9e6,inset_-7px_-7px_15px_#ffffff]';
const neumorphicShadowInset = 'shadow-[inset_7px_7px_15px_#d1d9e6,inset_-7px_-7px_15px_#ffffff]';


interface NeumorphicCardProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  interactive?: boolean;
}

export const NeumorphicCard: React.FC<NeumorphicCardProps> = ({ children, onClick, className = '', interactive = false }) => {
  const interactiveClasses = interactive
    ? `${neumorphicShadowHover} ${neumorphicShadowActive} cursor-pointer`
    : '';

  return (
    <div
      onClick={onClick}
      className={`${neumorphicBase} ${neumorphicShadow} ${interactiveClasses} p-4 ${className}`}
    >
      {children}
    </div>
  );
};


interface NeumorphicButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  className?: string;
  variant?: 'primary' | 'default';
}

export const NeumorphicButton: React.FC<NeumorphicButtonProps> = ({ children, className = '', variant = 'default', ...props }) => {
  const variantClasses = variant === 'primary' 
    ? 'text-blue-600 font-semibold' 
    : 'text-gray-700';
    
  return (
    <button
      {...props}
      className={`${neumorphicBase} ${neumorphicShadow} ${neumorphicShadowHover} ${neumorphicShadowActive} px-6 py-3 font-medium ${variantClasses} ${className}`}
    >
      {children}
    </button>
  );
};


interface NeumorphicInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    className?: string;
}

export const NeumorphicInput: React.FC<NeumorphicInputProps> = ({ className = '', ...props }) => {
    return (
        <input
            {...props}
            className={`${neumorphicBase} ${neumorphicShadowInset} w-full px-4 py-3 text-gray-700 placeholder-gray-400 focus:outline-none ${className}`}
        />
    );
};
