
import React, { ReactNode } from 'react';
import { User, Language, ApplicationStatus, StatusUrdu } from '../types';
import { UserCircleIcon, LogoutIcon, AdminIcon, BackIcon } from './icons';

interface HeaderProps {
    user: User;
    language: Language;
    toggleLanguage: () => void;
    onLogout: () => void;
    onNavigate: (page: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ user, language, toggleLanguage, onLogout, onNavigate }) => (
    <div className="bg-[#F0F2F5] p-4 flex justify-between items-center sticky top-0 z-10 shadow-[0_4px_10px_rgba(0,0,0,0.03)]">
        <h1 className="text-xl font-bold text-gray-700" onClick={() => onNavigate('dashboard')} style={{ cursor: 'pointer' }}>
            {language === 'en' ? 'Registration Portal' : 'رجسٹریشن پورٹل'}
        </h1>
        <div className="flex items-center space-x-4">
             {user.role === 'admin' && (
                <button onClick={() => onNavigate('admin')} className="text-gray-600 hover:text-blue-600">
                    <AdminIcon className="w-7 h-7" />
                </button>
            )}
            <button onClick={() => onNavigate('profile')} className="text-gray-600 hover:text-blue-600">
                <UserCircleIcon className="w-7 h-7" />
            </button>
            <button onClick={toggleLanguage} className="text-sm font-semibold text-gray-600 bg-white shadow-sm px-3 py-1 rounded-full hover:bg-gray-50">
                {language === 'en' ? 'اردو' : 'EN'}
            </button>
            <button onClick={onLogout} className="text-gray-600 hover:text-red-500">
                <LogoutIcon className="w-7 h-7" />
            </button>
        </div>
    </div>
);


interface PageWrapperProps {
  title: string;
  language: Language;
  onBack?: () => void;
  children: ReactNode;
}

export const PageWrapper: React.FC<PageWrapperProps> = ({ title, language, onBack, children }) => (
  <div className="p-4 sm:p-6">
    <div className="flex items-center mb-6">
      {onBack && (
        <button onClick={onBack} className="mr-4 p-2 rounded-full bg-[#F0F2F5] shadow-[5px_5px_10px_#d1d9e6,-5px_-5px_10px_#ffffff] active:shadow-[inset_5px_5px_10px_#d1d9e6,inset_-5px_-5px_10px_#ffffff]">
          <BackIcon className="w-6 h-6 text-gray-600" />
        </button>
      )}
      <h2 className={`text-2xl font-bold text-gray-800 ${language === 'ur' ? 'text-right w-full' : ''}`}>{title}</h2>
    </div>
    {children}
  </div>
);


interface StatusBadgeProps {
  status: ApplicationStatus;
  language: Language;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, language }) => {
  const statusConfig = {
    [ApplicationStatus.New]: 'bg-yellow-100 text-yellow-800',
    [ApplicationStatus.UnderReview]: 'bg-blue-100 text-blue-800',
    [ApplicationStatus.SubmittedToDept]: 'bg-purple-100 text-purple-800',
    [ApplicationStatus.InProgress]: 'bg-cyan-100 text-cyan-800',
    [ApplicationStatus.ReadyForPickup]: 'bg-indigo-100 text-indigo-800',
    [ApplicationStatus.Completed]: 'bg-green-100 text-green-800',
    [ApplicationStatus.Rejected]: 'bg-red-100 text-red-800',
  };

  return (
    <span className={`px-3 py-1 text-sm font-medium rounded-full ${statusConfig[status]}`}>
      {language === 'en' ? status : StatusUrdu[status]}
    </span>
  );
};
