
import React, { useState, Fragment } from 'react';
import { SupportIcon, PhoneIcon } from './icons';
import { NeumorphicButton, NeumorphicInput } from './Neumorphic';
import { Language } from '../types';

interface SupportWidgetProps {
    language: Language;
}

export const SupportWidget: React.FC<SupportWidgetProps> = ({ language }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [activeTab, setActiveTab] = useState<'chat' | 'callback'>('chat');
    const isUrdu = language === 'ur';

    const translations = {
        chat: { en: 'Chat', ur: 'چیٹ' },
        callback: { en: 'Request Callback', ur: 'کال بیک کی درخواست' },
        chatPlaceholder: { en: 'Type your message...', ur: 'اپنا پیغام ٹائپ کریں...' },
        send: { en: 'Send', ur: 'بھیجیں' },
        callbackTitle: { en: 'Leave your number', ur: 'اپنا نمبر چھوڑ دیں' },
        callbackDesc: { en: 'We will call you back as soon as possible.', ur: 'ہم جلد از جلد آپ کو واپس کال کریں گے۔' },
        phonePlaceholder: { en: 'Your phone number', ur: 'آپ کا فون نمبر' },
        submitRequest: { en: 'Submit Request', ur: 'درخواست جمع کروائیں' },
    };

    const handleCallbackSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        alert(isUrdu ? 'آپ کی درخواست موصول ہوگئی ہے۔' : 'Your request has been received.');
        setIsOpen(false);
    };

    if (!isOpen) {
        return (
            <button
                onClick={() => setIsOpen(true)}
                className="fixed bottom-6 right-6 bg-[#F0F2F5] w-16 h-16 rounded-full flex items-center justify-center shadow-[7px_7px_15px_#d1d9e6,-7px_-7px_15px_#ffffff] hover:shadow-[4px_4px_10px_#d1d9e6,-4px_-4px_10px_#ffffff] active:shadow-[inset_7px_7px_15px_#d1d9e6,inset_-7px_-7px_15px_#ffffff] transition-all duration-200 z-20"
                aria-label="Open support"
            >
                <SupportIcon className="w-8 h-8 text-blue-600" />
            </button>
        );
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-30 p-4" onClick={() => setIsOpen(false)}>
            <div
                className="bg-[#F0F2F5] rounded-2xl shadow-[10px_10px_20px_#d1d9e6,-10px_-10px_20px_#ffffff] w-full max-w-sm overflow-hidden"
                onClick={(e) => e.stopPropagation()}
                dir={isUrdu ? 'rtl' : 'ltr'}
            >
                {/* Header with tabs */}
                <div className="flex border-b border-gray-300">
                    <button
                        onClick={() => setActiveTab('chat')}
                        className={`flex-1 py-3 text-center font-semibold transition-colors ${activeTab === 'chat' ? 'text-blue-600 bg-white' : 'text-gray-600'}`}
                    >
                        {translations.chat[language]}
                    </button>
                    <button
                        onClick={() => setActiveTab('callback')}
                        className={`flex-1 py-3 text-center font-semibold transition-colors ${activeTab === 'callback' ? 'text-blue-600 bg-white' : 'text-gray-600'}`}
                    >
                        {translations.callback[language]}
                    </button>
                </div>
                {/* Content */}
                <div className="p-4">
                    {activeTab === 'chat' ? (
                        <div className="flex flex-col h-64">
                            <div className="flex-1 text-center flex items-center justify-center text-gray-500 text-sm">
                                {isUrdu ? 'سپورٹ ایجنٹ جلد ہی آپ کے ساتھ ہو گا۔' : 'A support agent will be with you shortly.'}
                            </div>
                            <div className="flex space-x-2 rtl:space-x-reverse">
                                <NeumorphicInput type="text" placeholder={translations.chatPlaceholder[language]} />
                                <NeumorphicButton variant="primary" className="px-4">
                                    {translations.send[language]}
                                </NeumorphicButton>
                            </div>
                        </div>
                    ) : (
                        <form className="space-y-4" onSubmit={handleCallbackSubmit}>
                            <div className="text-center">
                                <PhoneIcon className="w-12 h-12 text-blue-600 mx-auto mb-2" />
                                <h3 className="font-bold text-lg text-gray-800">{translations.callbackTitle[language]}</h3>
                                <p className="text-sm text-gray-500">{translations.callbackDesc[language]}</p>
                            </div>
                            <NeumorphicInput type="tel" placeholder={translations.phonePlaceholder[language]} required />
                            <NeumorphicButton type="submit" variant="primary" className="w-full">
                                {translations.submitRequest[language]}
                            </NeumorphicButton>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
};
