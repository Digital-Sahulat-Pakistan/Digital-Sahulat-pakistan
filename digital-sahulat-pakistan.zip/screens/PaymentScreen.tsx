
import React, { useState } from 'react';
import { NeumorphicCard, NeumorphicButton, NeumorphicInput } from '../components/Neumorphic';
import { PageWrapper } from '../components/Layout';
import { Service, Language, BankDetails } from '../types';

interface PaymentScreenProps {
  service: Service;
  language: Language;
  bankDetails: BankDetails;
  onBack: () => void;
  onSubmit: (service: Service, paymentSlip: File) => void;
}

const PaymentScreen: React.FC<PaymentScreenProps> = ({ service, language, bankDetails, onBack, onSubmit }) => {
  const [paymentSlip, setPaymentSlip] = useState<File | null>(null);
  const [error, setError] = useState('');
  const isUrdu = language === 'ur';

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setPaymentSlip(e.target.files[0]);
      setError('');
    }
  };

  const handleSubmit = () => {
    if (!paymentSlip) {
      setError(isUrdu ? 'براہ کرم ادائیگی کی رسید اپ لوڈ کریں۔' : 'Please upload the payment slip.');
      return;
    }
    onSubmit(service, paymentSlip);
  };

  return (
    <PageWrapper title={isUrdu ? 'ادائیگی' : 'Payment'} onBack={onBack} language={language}>
      <div className={`space-y-6 ${isUrdu ? 'text-right' : ''}`}>
        <NeumorphicCard>
          <h3 className="font-bold text-lg text-gray-800 mb-2">{isUrdu ? 'سروس' : 'Service'}</h3>
          <p className="text-gray-600">{service.name[language]}</p>
        </NeumorphicCard>
        
        <NeumorphicCard>
          <h3 className="font-bold text-lg text-gray-800 mb-2">{isUrdu ? 'قابل ادائیگی رقم' : 'Amount Payable'}</h3>
          <p className="text-2xl font-bold text-blue-600">PKR {service.fee.toLocaleString()}</p>
          <div className="mt-4 text-sm text-gray-500">
            <p>{isUrdu ? 'براہ کرم نیچے دیئے گئے بینک اکاؤنٹ میں رقم جمع کروائیں اور رسید اپ لوڈ کریں۔' : 'Please deposit the amount in the bank account below and upload the receipt.'}</p>
            <p className="mt-2 font-semibold">Account #: {bankDetails.accountNumber}</p>
            <p className="font-semibold">Bank: {bankDetails.bankName}</p>
          </div>
        </NeumorphicCard>

        <NeumorphicCard>
            <h3 className="font-bold text-lg text-gray-800 mb-3">{isUrdu ? 'ادائیگی کی رسید اپ لوڈ کریں' : 'Upload Payment Slip'}</h3>
            <NeumorphicInput type="file" onChange={handleFileChange} accept="image/*,.pdf"/>
            {paymentSlip && <p className="text-sm text-green-600 mt-2">{isUrdu ? 'فائل منتخب ہوگئی:' : 'File selected:'} {paymentSlip.name}</p>}
        </NeumorphicCard>

        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
        
        <div className="pt-4">
            <NeumorphicButton onClick={handleSubmit} className="w-full" variant="primary">
                {isUrdu ? 'درخواست جمع کروائیں' : 'Submit Application'}
            </NeumorphicButton>
        </div>
      </div>
    </PageWrapper>
  );
};

export default PaymentScreen;
