
import React from 'react';
import { NeumorphicCard } from '../components/Neumorphic';
import { PageWrapper } from '../components/Layout';
import { Service, Language } from '../types';
import { SERVICE_CATEGORIES } from '../constants';

interface DashboardScreenProps {
  onSelectService: (service: Service) => void;
  language: Language;
}

const DashboardScreen: React.FC<DashboardScreenProps> = ({ onSelectService, language }) => {
  const isUrdu = language === 'ur';
  return (
    <PageWrapper title={isUrdu ? 'ہماری خدمات' : 'Our Services'} language={language}>
      <div className="space-y-8">
        {SERVICE_CATEGORIES.map((category, index) => (
          <section key={index}>
            <h2 className={`text-xl font-bold text-gray-700 mb-4 pb-2 border-b-2 border-gray-200 ${isUrdu ? 'text-right' : ''}`}>
              {category.title[language]}
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6">
              {category.items.map((service) => (
                <NeumorphicCard 
                  key={service.id}
                  onClick={() => onSelectService(service)}
                  interactive={true}
                  className="flex flex-col items-center justify-center text-center p-4 aspect-square"
                >
                  <div className="w-12 h-12 mb-3 text-blue-600">
                      <service.icon />
                  </div>
                  <h3 className="font-semibold text-gray-700 text-sm leading-tight">
                      {service.name[language]}
                  </h3>
                  <p className="text-xs text-blue-500 font-bold mt-2">
                      PKR {service.fee}
                  </p>
                </NeumorphicCard>
              ))}
            </div>
          </section>
        ))}
      </div>
    </PageWrapper>
  );
};

export default DashboardScreen;
