
import React, { useState, useEffect } from 'react';
import { NeumorphicCard, NeumorphicButton, NeumorphicInput } from '../components/Neumorphic';
import { PageWrapper, StatusBadge } from '../components/Layout';
import { Application, Language, ApplicationStatus, Service, BankDetails, StatusUrdu } from '../types';

interface AdminScreenProps {
  allApplications: Application[];
  services: Service[];
  language: Language;
  bankDetails: BankDetails;
  onBack: () => void;
  onUpdateStatus: (appId: string, status: ApplicationStatus) => void;
  onUpdateFee: (serviceId: string, newFee: number) => void;
  onUpdateBankDetails: (details: BankDetails) => void;
}

const AdminScreen: React.FC<AdminScreenProps> = ({ allApplications, services, language, bankDetails, onBack, onUpdateStatus, onUpdateFee, onUpdateBankDetails }) => {
  const isUrdu = language === 'ur';
  const [currentBankDetails, setCurrentBankDetails] = useState(bankDetails);

  useEffect(() => {
    setCurrentBankDetails(bankDetails);
  }, [bankDetails]);
  
  const handleFeeChange = (serviceId: string, feeStr: string) => {
    const fee = parseInt(feeStr, 10);
    if (!isNaN(fee)) {
        onUpdateFee(serviceId, fee);
    }
  };

  const handleBankDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentBankDetails(prev => ({...prev, [e.target.name]: e.target.value }));
  };

  const handleBankDetailsSave = () => {
    onUpdateBankDetails(currentBankDetails);
  };

  return (
    <PageWrapper title={isUrdu ? 'ایڈمن پینل' : 'Admin Panel'} onBack={onBack} language={language}>
      <div className={`space-y-8 ${isUrdu ? 'text-right' : ''}`}>
        
        {/* Bank Account Management */}
        <NeumorphicCard>
          <h3 className="font-bold text-xl text-gray-800 mb-4">{isUrdu ? 'بینک اکاؤنٹ کی تفصیلات' : 'Manage Bank Details'}</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">{isUrdu ? 'اکاؤنٹ نمبر' : 'Account Number'}</label>
              <NeumorphicInput name="accountNumber" value={currentBankDetails.accountNumber} onChange={handleBankDetailsChange} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">{isUrdu ? 'بینک کا نام' : 'Bank Name'}</label>
              <NeumorphicInput name="bankName" value={currentBankDetails.bankName} onChange={handleBankDetailsChange} />
            </div>
            <div className="pt-2">
                <NeumorphicButton onClick={handleBankDetailsSave} variant="primary" className="w-full sm:w-auto">
                    {isUrdu ? 'محفوظ کریں' : 'Save Changes'}
                </NeumorphicButton>
            </div>
          </div>
        </NeumorphicCard>

        {/* Service Fee Management */}
        <NeumorphicCard>
          <h3 className="font-bold text-xl text-gray-800 mb-4">{isUrdu ? 'سروس فیس کا انتظام' : 'Manage Service Fees'}</h3>
          <div className="space-y-4">
            {services.map(service => (
              <div key={service.id} className="flex items-center justify-between p-3 rounded-lg bg-[#F0F2F5] shadow-[inset_3px_3px_6px_#d1d9e6,inset_-3px_-3px_6px_#ffffff]">
                <span className="text-gray-700">{service.name[language]}</span>
                <div className="w-32">
                    <NeumorphicInput 
                        type="number"
                        value={service.fee}
                        onChange={(e) => handleFeeChange(service.id, e.target.value)}
                        className="text-center"
                    />
                </div>
              </div>
            ))}
          </div>
        </NeumorphicCard>

        {/* Application Management */}
        <NeumorphicCard>
          <h3 className="font-bold text-xl text-gray-800 mb-4">{isUrdu ? 'درخواستوں کا انتظام' : 'Manage Applications'}</h3>
          <div className="space-y-4">
            {allApplications.length > 0 ? allApplications.map(app => (
              <div key={app.id} className="p-4 rounded-lg bg-[#F0F2F5] shadow-[inset_5px_5px_10px_#d1d9e6,inset_-5px_-5px_10px_#ffffff]">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-bold text-gray-800">{app.serviceName[language]}</p>
                    <p className="text-sm text-gray-600">{app.userName} ({isUrdu ? 'ID: ' : 'ID: '}{app.userId})</p>
                    <p className="text-xs text-gray-500">{isUrdu ? 'جمع کرانے کی تاریخ: ' : 'Submitted: '}{app.submittedAt.toLocaleString()}</p>
                  </div>
                  <StatusBadge status={app.status} language={language} />
                </div>
                <div className="flex items-center justify-end space-x-2 mt-2">
                    <select
                        value={app.status}
                        onChange={(e) => onUpdateStatus(app.id, e.target.value as ApplicationStatus)}
                        className="bg-white border border-gray-300 text-gray-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2"
                    >
                        {Object.values(ApplicationStatus).map(status => (
                            <option key={status} value={status}>
                                {isUrdu ? StatusUrdu[status] : status}
                            </option>
                        ))}
                    </select>
                </div>
              </div>
            )) : (
              <p className="text-gray-500 text-center">{isUrdu ? 'کوئی درخواست نہیں ملی۔' : 'No applications found.'}</p>
            )}
          </div>
        </NeumorphicCard>
      </div>
    </PageWrapper>
  );
};

export default AdminScreen;
