
import React, { useState } from 'react';
import { NeumorphicCard, NeumorphicInput, NeumorphicButton } from '../components/Neumorphic';

interface LoginScreenProps {
  onLogin: (phone: string, password: string) => boolean;
  onNavigateToSignup: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onNavigateToSignup }) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) {
        setError('Please enter phone and password.');
        return;
    }
    const success = onLogin(phone, password);
    if (!success) {
      setError('Invalid phone number or password.');
    } else {
        setError('');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#F0F2F5]">
      <NeumorphicCard className="w-full max-w-sm">
        <div className="text-center p-4">
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Welcome Back</h1>
          <p className="text-gray-500">Sign in to your account</p>
        </div>
        
        {error && <p className="text-red-500 text-sm text-center mb-4">{error}</p>}
        
        <form onSubmit={handleLogin} className="space-y-6 p-4">
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-600 mb-2">Phone Number</label>
              <NeumorphicInput 
                id="phone"
                type="tel" 
                placeholder="03001234567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </div>
             <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-600 mb-2">Password</label>
              <NeumorphicInput 
                id="password"
                type="password" 
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <NeumorphicButton type="submit" className="w-full" variant="primary">
              Login
            </NeumorphicButton>
             <p className="text-center text-sm text-gray-500">
                Don't have an account?{' '}
                <button
                    type="button"
                    onClick={onNavigateToSignup}
                    className="font-medium text-blue-600 hover:underline"
                >
                    Sign up
                </button>
            </p>
        </form>
      </NeumorphicCard>
    </div>
  );
};

export default LoginScreen;
