
import React, { useState } from 'react';
import { NeumorphicCard, NeumorphicInput, NeumorphicButton } from '../components/Neumorphic';
import { User } from '../types';

interface SignupScreenProps {
  onSignup: (newUser: Omit<User, 'id' | 'role'>) => boolean;
  onNavigateToLogin: () => void;
}

const SignupScreen: React.FC<SignupScreenProps> = ({ onSignup, onNavigateToLogin }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !password) {
        setError('Please fill in all fields.');
        return;
    }
     if (phone.length < 11) {
      setError('Please enter a valid phone number.');
      return;
    }
    const success = onSignup({ name, phone, password });
    if (!success) {
      setError('This phone number is already registered.');
    } else {
        setError('');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#F0F2F5]">
      <NeumorphicCard className="w-full max-w-sm">
        <div className="text-center p-4">
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Create Account</h1>
          <p className="text-gray-500">Get started with a new account</p>
        </div>
        
        {error && <p className="text-red-500 text-sm text-center mb-4">{error}</p>}
        
        <form onSubmit={handleSignup} className="space-y-6 p-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-600 mb-2">Full Name</label>
              <NeumorphicInput 
                id="name"
                type="text" 
                placeholder="e.g. Ahmed Khan"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-600 mb-2">Phone Number</label>
              <NeumorphicInput 
                id="phone"
                type="tel" 
                placeholder="03001234567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-600 mb-2">Password</label>
              <NeumorphicInput 
                id="password"
                type="password" 
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <NeumorphicButton type="submit" className="w-full" variant="primary">
              Sign Up
            </NeumorphicButton>
            <p className="text-center text-sm text-gray-500">
                Already have an account?{' '}
                <button
                    type="button"
                    onClick={onNavigateToLogin}
                    className="font-medium text-blue-600 hover:underline"
                >
                    Log in
                </button>
            </p>
        </form>
      </NeumorphicCard>
    </div>
  );
};

export default SignupScreen;
