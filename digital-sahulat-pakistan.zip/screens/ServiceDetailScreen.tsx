
import React from 'react';
import { NeumorphicCard, NeumorphicButton } from '../components/Neumorphic';
import { PageWrapper } from '../components/Layout';
import { Service, Language } from '../types';

interface ServiceDetailScreenProps {
  service: Service;
  language: Language;
  onBack: () => void;
  onApply: (service: Service) => void;
}

const ServiceDetailScreen: React.FC<ServiceDetailScreenProps> = ({ service, language, onBack, onApply }) => {
  const isUrdu = language === 'ur';

  return (
    <PageWrapper title={service.name[language]} onBack={onBack} language={language}>
      <div className={`space-y-6 ${isUrdu ? 'text-right' : ''}`}>
        <NeumorphicCard>
          <p className="text-gray-600">{service.description[language]}</p>
        </NeumorphicCard>

        <NeumorphicCard>
          <h3 className="font-bold text-lg text-gray-800 mb-3">{isUrdu ? 'فیس' : 'Fee'}</h3>
          <p className="text-2xl font-bold text-blue-600">PKR {service.fee.toLocaleString()}</p>
        </NeumorphicCard>
        
        <NeumorphicCard>
          <h3 className="font-bold text-lg text-gray-800 mb-3">{isUrdu ? 'مطلوبہ دستاویزات' : 'Required Documents'}</h3>
          <ul className={`list-disc ${isUrdu ? 'list-inside' : 'ml-5'} space-y-2 text-gray-600`}>
            {service.requiredDocs[language].map((doc, index) => (
              <li key={index}>{doc}</li>
            ))}
          </ul>
        </NeumorphicCard>
        
        <div className="pt-4">
            <NeumorphicButton onClick={() => onApply(service)} className="w-full" variant="primary">
                {isUrdu ? 'ابھی اپلائی کریں' : 'Apply Now'}
            </NeumorphicButton>
        </div>
      </div>
    </PageWrapper>
  );
};

export default ServiceDetailScreen;
