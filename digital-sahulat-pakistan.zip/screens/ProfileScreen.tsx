
import React from 'react';
import { NeumorphicCard } from '../components/Neumorphic';
import { PageWrapper, StatusBadge } from '../components/Layout';
import { Application, User, Language, ApplicationStatus } from '../types';

interface ProfileScreenProps {
  user: User;
  applications: Application[];
  language: Language;
  onBack: () => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ user, applications, language, onBack }) => {
  const isUrdu = language === 'ur';

  return (
    <PageWrapper title={isUrdu ? 'پروفائل اور درخواستیں' : 'Profile & Applications'} onBack={onBack} language={language}>
      <div className={`space-y-6 ${isUrdu ? 'text-right' : ''}`}>
        <NeumorphicCard>
            <h3 className="font-bold text-lg text-gray-800 mb-3">{isUrdu ? 'صارف کی تفصیلات' : 'User Details'}</h3>
            <div className="text-gray-600 space-y-1">
                <p><strong>{isUrdu ? 'نام:' : 'Name:'}</strong> {user.name}</p>
                <p><strong>{isUrdu ? 'فون:' : 'Phone:'}</strong> {user.phone}</p>
            </div>
        </NeumorphicCard>
        
        <NeumorphicCard>
          <h3 className="font-bold text-lg text-gray-800 mb-4">{isUrdu ? 'درخواست کی تاریخ' : 'Application History'}</h3>
          <div className="space-y-4">
            {applications.length > 0 ? applications.map(app => (
              <div key={app.id} className="p-3 rounded-lg bg-[#F0F2F5] shadow-[inset_5px_5px_10px_#d1d9e6,inset_-5px_-5px_10px_#ffffff]">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold text-gray-700">{app.serviceName[language]}</p>
                    <p className="text-sm text-gray-500">
                      {isUrdu ? 'جمع کرانے کی تاریخ:' : 'Submitted:'} {app.submittedAt.toLocaleDateString()}
                    </p>
                  </div>
                  <StatusBadge status={app.status} language={language} />
                </div>
                {app.status === ApplicationStatus.Rejected && app.rejectionReason && (
                   <p className="text-xs text-red-600 mt-2">
                       <strong>{isUrdu ? 'مسترد کرنے کی وجہ: ' : 'Reason: '}</strong> 
                       {app.rejectionReason}
                    </p>
                )}
              </div>
            )) : (
              <p className="text-gray-500 text-center">{isUrdu ? 'کوئی درخواست نہیں ملی۔' : 'No applications found.'}</p>
            )}
          </div>
        </NeumorphicCard>
      </div>
    </PageWrapper>
  );
};

export default ProfileScreen;
