
import React, { useState, useEffect } from 'react';
import LoginScreen from './screens/LoginScreen';
import SignupScreen from './screens/SignupScreen';
import DashboardScreen from './screens/DashboardScreen';
import ServiceDetailScreen from './screens/ServiceDetailScreen';
import PaymentScreen from './screens/PaymentScreen';
import ProfileScreen from './screens/ProfileScreen';
import AdminScreen from './screens/AdminScreen';
import { Header } from './components/Layout';
import { SupportWidget } from './components/Support';
import { User, Language, Service, Application, ApplicationStatus, BankDetails } from './types';
import { MOCK_USERS, MOCK_APPLICATIONS, SERVICE_CATEGORIES } from './constants';

type AppState =
  | { screen: 'login' }
  | { screen: 'signup' }
  | { screen: 'dashboard' }
  | { screen: 'serviceDetail'; service: Service }
  | { screen: 'payment'; service: Service }
  | { screen: 'profile' }
  | { screen: 'admin' };

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [language, setLanguage] = useState<Language>('en');
  const [appState, setAppState] = useState<AppState>({ screen: 'login' });
  const [allApplications, setAllApplications] = useState<Application[]>(MOCK_APPLICATIONS);
  
  // Flatten services from categories for easy lookup
  const [services, setServices] = useState<Service[]>(SERVICE_CATEGORIES.flatMap(cat => cat.items));

  const [bankDetails, setBankDetails] = useState<BankDetails>({
    accountNumber: '0123-456789-001',
    bankName: 'National Bank of Pakistan'
  });

  const toggleLanguage = () => setLanguage(lang => (lang === 'en' ? 'ur' : 'en'));

  const handleLogin = (phone: string, password: string): boolean => {
    const foundUser = users.find(u => u.phone === phone && u.password === password);
    if (foundUser) {
      setUser(foundUser);
      setAppState({ screen: 'dashboard' });
      return true;
    }
    return false;
  };
  
  const handleSignup = (newUser: Omit<User, 'id' | 'role'>): boolean => {
    if (users.some(u => u.phone === newUser.phone)) {
        return false; // User already exists
    }
    const createdUser: User = {
        ...newUser,
        id: `user-${Date.now()}`,
        role: 'user',
    };
    setUsers(prev => [...prev, createdUser]);
    setUser(createdUser);
    setAppState({ screen: 'dashboard' });
    return true;
  };

  const handleLogout = () => {
    setUser(null);
    setAppState({ screen: 'login' });
  };

  const navigate = (page: string, data?: any) => {
    switch(page) {
        case 'login':
            setAppState({ screen: 'login' });
            break;
        case 'signup':
            setAppState({ screen: 'signup' });
            break;
        case 'dashboard':
            setAppState({ screen: 'dashboard' });
            break;
        case 'serviceDetail':
            setAppState({ screen: 'serviceDetail', service: data });
            break;
        case 'payment':
            setAppState({ screen: 'payment', service: data });
            break;
        case 'profile':
            setAppState({ screen: 'profile' });
            break;
        case 'admin':
            if (user?.role === 'admin') {
                setAppState({ screen: 'admin' });
            }
            break;
        default:
            setAppState({ screen: 'dashboard' });
    }
  };

  const handleApplicationSubmit = (service: Service, paymentSlip: File) => {
    if (!user) return;
    const newApplication: Application = {
      id: `app-${Date.now()}`,
      userId: user.id,
      userName: user.name,
      serviceId: service.id,
      serviceName: service.name,
      status: ApplicationStatus.New,
      submittedAt: new Date(),
      updatedAt: new Date(),
      paymentSlip,
    };
    setAllApplications(prev => [newApplication, ...prev]);
    alert(language === 'en' ? 'Application Submitted Successfully!' : '!کامیابی کے ساتھ درخواست جمع ہو گئی');
    setAppState({ screen: 'profile' });
  };

  const handleUpdateStatus = (appId: string, status: ApplicationStatus) => {
    setAllApplications(apps => apps.map(app => 
        app.id === appId ? { ...app, status, updatedAt: new Date() } : app
    ));
  };
  
  const handleUpdateFee = (serviceId: string, newFee: number) => {
    setServices(currentServices => currentServices.map(service => 
        service.id === serviceId ? { ...service, fee: newFee } : service
    ));
    // Also update the categorized structure if needed, but for simplicity, we manage a flat list for updates.
  };

  const handleUpdateBankDetails = (details: BankDetails) => {
    setBankDetails(details);
    alert('Bank details updated successfully!');
  };


  const renderScreen = () => {
    if (!user) {
        switch (appState.screen) {
            case 'signup':
                return <SignupScreen onSignup={handleSignup} onNavigateToLogin={() => navigate('login')} />;
            case 'login':
            default:
                return <LoginScreen onLogin={handleLogin} onNavigateToSignup={() => navigate('signup')} />;
        }
    }

    switch (appState.screen) {
      case 'dashboard':
        return <DashboardScreen onSelectService={(service) => navigate('serviceDetail', service)} language={language} />;
      case 'serviceDetail':
        return <ServiceDetailScreen service={appState.service} language={language} onBack={() => navigate('dashboard')} onApply={(service) => navigate('payment', service)} />;
      case 'payment':
        return <PaymentScreen service={appState.service} language={language} bankDetails={bankDetails} onBack={() => navigate('serviceDetail', appState.service)} onSubmit={handleApplicationSubmit} />;
      case 'profile':
        return <ProfileScreen user={user} applications={allApplications.filter(app => app.userId === user?.id)} language={language} onBack={() => navigate('dashboard')} />;
      case 'admin':
         return <AdminScreen 
            allApplications={allApplications} 
            services={services} 
            language={language} 
            bankDetails={bankDetails}
            onBack={() => navigate('dashboard')} 
            onUpdateStatus={handleUpdateStatus} 
            onUpdateFee={handleUpdateFee}
            onUpdateBankDetails={handleUpdateBankDetails}
        />;
      default:
        return <DashboardScreen onSelectService={(service) => navigate('serviceDetail', service)} language={language} />;
    }
  };
  
  if (!user) {
    return renderScreen();
  }

  return (
    <div className="max-w-xl mx-auto bg-[#F0F2F5] min-h-screen shadow-2xl shadow-gray-300">
        <Header user={user} language={language} toggleLanguage={toggleLanguage} onLogout={handleLogout} onNavigate={(page) => navigate(page)} />
        <main className="relative">
            {renderScreen()}
            <SupportWidget language={language} />
        </main>
    </div>
  );
};

export default App;
