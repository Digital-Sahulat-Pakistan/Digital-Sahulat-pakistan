
// FIX: Import ComponentType from react to resolve 'React' namespace error.
import type { ComponentType } from 'react';

export type Language = 'en' | 'ur';

export interface Service {
  id: string;
  name: { en: string; ur: string };
  description: { en: string; ur: string };
  fee: number;
  icon: ComponentType<{ className?: string }>;
  requiredDocs: { en: string[]; ur:string[] };
}

export enum ApplicationStatus {
  New = 'New',
  UnderReview = 'Under Review',
  SubmittedToDept = 'Submitted to Dept',
  InProgress = 'In Progress',
  ReadyForPickup = 'Ready for Pickup',
  Completed = 'Completed',
  Rejected = 'Rejected',
}

export const StatusUrdu = {
  [ApplicationStatus.New]: 'نیا',
  [ApplicationStatus.UnderReview]: 'زیر غور',
  [ApplicationStatus.SubmittedToDept]: 'محکمہ کو জমা',
  [ApplicationStatus.InProgress]: 'کارروائی میں',
  [ApplicationStatus.ReadyForPickup]: 'وصولی کے لیے تیار',
  [ApplicationStatus.Completed]: 'مکمل',
  [ApplicationStatus.Rejected]: 'مسترد',
};

export interface Application {
  id: string;
  userId: string;
  userName: string;
  serviceId: string;
  serviceName: { en: string; ur: string };
  status: ApplicationStatus;
  submittedAt: Date;
  updatedAt: Date;
  rejectionReason?: string;
  paymentSlip?: File;
}

export interface User {
  id: string;
  name: string;
  phone: string;
  password?: string;
  role: 'user' | 'admin';
}

export interface BankDetails {
    accountNumber: string;
    bankName: string;
}
